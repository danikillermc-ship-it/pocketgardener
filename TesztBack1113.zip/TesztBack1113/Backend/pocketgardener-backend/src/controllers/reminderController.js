import db from "../config/db.js";

export async function listReminders(req, res) {
  try {
    const userId = req.userId;
    const [rows] = await db.query(
      "SELECT * FROM reminders WHERE user_id = ? ORDER BY created_at DESC",
      [userId]
    );
    res.json(rows);
  } catch (err) {
    console.error("listReminders error:", err);
    res.status(500).json({ error: "Server error fetching reminders" });
  }
}

export async function createReminder(req, res) {
  console.log("REQUEST BODY:", req.body);

  const { plant_id, type, note, remind_at } = req.body;

  if (!plant_id || !type || !remind_at) {
    return res.status(400).json({
      error: "plant_id, type, and remind_at are required."
    });
  }

  try {
    const userId = req.userId;

    await db.query(
      "INSERT INTO reminders (user_id, plant_id, type, note, remind_at) VALUES (?, ?, ?, ?, ?)",
      [userId, plant_id, type, note || null, remind_at]
    );

    res.json({ message: "Reminder created successfully" });
    console.error("❌ createReminder debug:", { userId, plant_id, type, remind_at, frequency });
  } catch (err) {
    console.error("createReminder error:", err);
    res.status(500).json({ error: "Server error creating reminder" });
  }
}


export async function deleteReminder(req, res) {
  const reminderId = req.params.id;
  try {
    const userId = req.userId;
    await db.query(
      "DELETE FROM reminders WHERE id = ? AND user_id = ?",
      [reminderId, userId]
    );
    res.json({ message: "Reminder deleted successfully" });
  } catch (err) {
    console.error("deleteReminder error:", err);
    res.status(500).json({ error: "Server error deleting reminder" });
  }
}
