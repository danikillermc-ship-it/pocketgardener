// src/controllers/userController.js
import db from "../config/db.js";

export async function getMe(req, res) {
  try {
    const userId = req.userId; // Make sure your auth middleware sets req.userId

    const [rows] = await db.query(
      "SELECT id, email, name, created_at FROM users WHERE id = ?",
      [userId]
    );

    if (!rows.length) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(rows[0]);
  } catch (err) {
    console.error("getMe error:", err);
    res.status(500).json({ message: "Server error" });
  }
}

// ✅ Update profile info
export async function updateMe(req, res) {
  try {
    const userId = req.user.id;
    const { name, email } = req.body;

    if (!name || !email)
      return res.status(400).json({ message: "Name and email are required" });

    await db.query("UPDATE users SET name = ?, email = ? WHERE id = ?", [name, email, userId]);

    const [rows] = await db.query("SELECT id, name, email FROM users WHERE id = ?", [userId]);
    res.json(rows[0]);
  } catch (err) {
    console.error("updateMe error:", err);
    res.status(500).json({ message: "Server error updating profile" });
  }
}
