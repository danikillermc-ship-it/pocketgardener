// src/controllers/planController.js
import db from "../config/db.js";

// GET all plans for logged-in user
export async function listPlans(req, res) {
  try {
    const userId = req.userId;
    const [rows] = await db.query(
      "SELECT * FROM plans WHERE user_id = ? ORDER BY created_at DESC",
      [userId]
    );
    res.json(rows);
  } catch (err) {
    console.error("listPlans error:", err);
    res.status(500).json({ error: "Server error retrieving plans" });
  }
}

// CREATE a new plan
export async function createPlan(req, res) {
  const { title, description } = req.body;

  if (!title) return res.status(400).json({ error: "Title is required" });

  try {
    const userId = req.userId;
    await db.query(
      "INSERT INTO plans (user_id, title, description) VALUES (?, ?, ?)",
      [userId, title, description || ""]
    );
    res.json({ message: "Plan created successfully" });
  } catch (err) {
    console.error("createPlan error:", err);
    res.status(500).json({ error: "Server error creating plan" });
  }
}

// UPDATE a plan
export async function updatePlan(req, res) {
  const { title, description, status } = req.body;
  const planId = req.params.id;

  try {
    const userId = req.userId;
    await db.query(
      "UPDATE plans SET title = ?, description = ?, status = ? WHERE id = ? AND user_id = ?",
      [title, description, status, planId, userId]
    );
    res.json({ message: "Plan updated successfully" });
  } catch (err) {
    console.error("updatePlan error:", err);
    res.status(500).json({ error: "Server error updating plan" });
  }
}

// DELETE a plan
export async function deletePlan(req, res) {
  const planId = req.params.id;

  try {
    const userId = req.userId;
    await db.query("DELETE FROM plans WHERE id = ? AND user_id = ?", [
      planId,
      userId,
    ]);
    res.json({ message: "Plan deleted successfully" });
  } catch (err) {
    console.error("deletePlan error:", err);
    res.status(500).json({ error: "Server error deleting plan" });
  }
}
