import db from "../config/db.js";

// GET plants belonging to logged-in user
export async function listPlants(req, res) {
  try {
    const [rows] = await db.query(
      "SELECT id, name, photo, notes, created_at FROM plants WHERE user_id = ? ORDER BY created_at DESC",
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error("listPlants error:", err);
    res.status(500).json({ message: "Server error fetching plants" });
  }
}

// ADD plant
export async function createPlant(req, res) {
  const { name, photo, notes } = req.body;
  console.log("USER ID:", req.userId);
  if (!name) return res.status(400).json({ message: "Name is required" });

  try {
    await db.query(
      "INSERT INTO plants (user_id, name, photo, notes) VALUES (?, ?, ?, ?)",
      [req.user.id, name, photo || "", notes || ""]
    );
    res.json({ message: "Plant added" });
  } catch (err) {
    console.error("createPlant error:", err);
    res.status(500).json({ message: "Server error adding plant" });
  }
}

// DELETE plant
export async function deletePlant(req, res) {
  try {
    await db.query("DELETE FROM plants WHERE id = ? AND user_id = ?", [
      req.params.id,
      req.user.id,
    ]);
    res.json({ message: "Plant deleted" });
  } catch (err) {
    console.error("deletePlant error:", err);
    res.status(500).json({ message: "Server error deleting plant" });
  }
}
