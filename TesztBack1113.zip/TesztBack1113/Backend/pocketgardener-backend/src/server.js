// src/server.js
import dotenv from "dotenv";
dotenv.config();

import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

import authRoutes from "./routes/auth.js";
import userRoutes from "./routes/users.js";
import planRoutes from "./routes/plans.js";
import reminderRoutes from "./routes/reminders.js";
import plantRoutes from './routes/plants.js';
import communityRoutes from "./routes/community.js";
import adminRoutes from "./routes/admin.js";

const app = express();

// Security middleware
app.use(helmet());
app.use(express.json());

// CORS (change origin to match your frontend address if different)
app.use(
  cors({
    origin: "http://192.168.0.232:8080", // or http://127.0.0.1:5500
    credentials: true,
  })
);

// Basic API rate limiting
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,
});
app.use(limiter);

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/plans", planRoutes);
app.use('/api/reminders', reminderRoutes);
app.use('/api/plants', plantRoutes);
app.use("/api/community", communityRoutes);
app.use("/api/admin", adminRoutes);


// Basic test endpoint
app.get("/", (req, res) => res.json({ status: "PocketGardener API running" }));

// Start server
const PORT = process.env.PORT || 4000;
app.listen(4000, "0.0.0.0", () => {
  console.log("Server running on all network interfaces");
});

