import express from "express";
import db from "../config/db.js";
import authenticate from "../middleware/auth.js";

const router = express.Router();

// ✅ Only allow admins
async function adminOnly(req, res, next) {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: "Access denied: admin only." });
  }
  next();
}

// === ROUTES ===

// Get all users
router.get("/users", authenticate, adminOnly, async (req, res) => {
  const [users] = await db.query("SELECT id, name, email, role FROM users");
  res.json(users);
});

// Delete user
router.delete("/users/:id", authenticate, adminOnly, async (req, res) => {
  await db.query("DELETE FROM users WHERE id = ?", [req.params.id]);
  res.json({ success: true });
});

// Update user role
router.put("/users/:id/role", authenticate, adminOnly, async (req, res) => {
  const { role } = req.body;
  if (!["admin", "user"].includes(role)) {
    return res.status(400).json({ error: "Invalid role" });
  }
  await db.query("UPDATE users SET role = ? WHERE id = ?", [role, req.params.id]);
  res.json({ success: true, message: `Role updated to ${role}` });
});

// Get all community posts


// ✅ Get all community posts (with author names)
router.get("/community", authenticate, adminOnly, async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT community_listings.*, users.name AS user_name, users.email AS user_email
      FROM community_listings
      LEFT JOIN users ON users.id = community_listings.user_id
      ORDER BY community_listings.created_at DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error("❌ Error loading community:", err);
    res.status(500).json({ error: "Server error loading community events" });
  }
});


// Delete community post
router.delete("/community/:id", authenticate, adminOnly, async (req, res) => {
  await db.query("DELETE FROM community_listings WHERE id = ?", [req.params.id]);
  res.json({ success: true });
});

// ✅ Safe clear database (keep admin accounts)
router.delete("/clear", authenticate, adminOnly, async (req, res) => {
  console.log("🧹 /api/admin/clear endpoint hit by", req.user?.email); // <-- add this
  try {
    await db.query("DELETE FROM reminders");
    await db.query("DELETE FROM plants");
    await db.query("DELETE FROM community_listings");
    await db.query("DELETE FROM users WHERE role != 'admin'");

    res.json({ success: true, message: "✅ Database cleared, admin accounts kept." });
  } catch (err) {
    console.error("❌ Error clearing DB:", err);
    res.status(500).json({ error: "Server error clearing database" });
  }
});



export default router;
