import express from "express";
import authenticate from "../middleware/auth.js";
import { listReminders, createReminder, deleteReminder } from "../controllers/reminderController.js";

const router = express.Router();

router.use(authenticate);

router.get("/", listReminders);
router.post("/", createReminder);
router.delete("/:id", deleteReminder);

export default router;
