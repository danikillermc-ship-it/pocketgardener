import express from "express";
import db from "../config/db.js";
import authenticate from "../middleware/auth.js";

const router = express.Router();

// Get all listings
router.get("/", async (req, res) => {
  const [results] = await db.query(
    "SELECT community_listings.*, users.name FROM community_listings JOIN users ON users.id = community_listings.user_id ORDER BY created_at DESC"
  );
  res.json(results);
});

// Create a listing
router.post("/", authenticate, async (req, res) => {
  const { type, title, description, location, contact } = req.body;
  const userId = req.user.id;

  await db.query(
    "INSERT INTO community_listings (user_id, type, title, description, location, contact) VALUES (?, ?, ?, ?, ?, ?)",
    [userId, type, title, description, location, contact]
  );

  res.json({ success: true });
});

// ✅ Delete a listing (only by owner)
router.delete("/:id", authenticate, async (req, res) => {
  try {
    const communityId = req.params.id;
    const userId = req.user.id;

    const [rows] = await db.query(
      "SELECT * FROM community_listings WHERE id = ?",
      [communityId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: "Listing not found" });
    }

    const listing = rows[0];
    if (listing.user_id !== userId) {
      return res
        .status(403)
        .json({ error: "You can only delete your own listings." });
    }

    await db.query("DELETE FROM community_listings WHERE id = ?", [communityId]);
    res.json({ success: true });
  } catch (err) {
    console.error("❌ Error deleting community listing:", err);
    res.status(500).json({ error: "Server error deleting listing" });
  }
});

export default router;
