import express from "express";
import authenticate from "../middleware/auth.js";
import { listPlants, createPlant, deletePlant } from "../controllers/plantController.js";

const router = express.Router();

router.use(authenticate);

router.get("/", listPlants);      // GET /api/plants
router.post("/", createPlant);    // POST /api/plants
router.delete("/:id", deletePlant); // DELETE /api/plants/:id

export default router;
