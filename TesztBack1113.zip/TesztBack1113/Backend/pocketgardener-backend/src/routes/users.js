// src/routes/users.js
import express from "express";
import authenticateToken from "../middleware/auth.js";
import { getMe, updateMe} from "../controllers/userController.js";

const router = express.Router();

router.get("/me", authenticateToken, getMe);
router.put("/me", authenticateToken, updateMe); // ✅ added

export default router;
