// src/routes/plans.js
import express from "express";
import authenticate from "../middleware/auth.js";
import {
  listPlans,
  createPlan,
  updatePlan,
  deletePlan
} from "../controllers/planController.js";

const router = express.Router();

// Apply authentication to all plan routes
router.use(authenticate);

// Routes
router.get("/", listPlans);
router.post("/", createPlan);
router.put("/:id", updatePlan);
router.delete("/:id", deletePlan);

// ✅ Export router as default (important!)
export default router;
