import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET;

export default function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ message: "Missing authorization header" });

  const token = authHeader.split(" ")[1];
  if (!token) return res.status(401).json({ message: "Missing token" });

  try {
    const user = jwt.verify(token, JWT_SECRET);
    
    // VERY IMPORTANT → Attach user id
    req.userId = user.id;
    req.user = user;
    
    next();
  } catch (err) {
    return res.status(403).json({ message: "Invalid or expired token" });
  }
}
