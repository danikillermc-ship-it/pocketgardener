-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2025 at 04:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pocketgardener`
--

-- --------------------------------------------------------

--
-- Table structure for table `community_listings`
--

CREATE TABLE `community_listings` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `type` enum('cutting','seeds','event','tools') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `community_listings`
--

INSERT INTO `community_listings` (`id`, `user_id`, `type`, `title`, `description`, `location`, `contact`, `created_at`) VALUES
(19, 1, 'cutting', 'killermc', '', 'Sopron', '', '2025-11-13 15:56:32');

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('active','archived','completed') DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plants`
--

CREATE TABLE `plants` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `photo` longtext DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plants`
--

INSERT INTO `plants` (`id`, `user_id`, `name`, `photo`, `notes`, `created_at`) VALUES
(3, 2, 'pocketgardener.csapat', '', 'Kortee', '2025-11-08 21:39:02'),
(5, 4, 'Korte', '', '', '2025-11-10 12:22:46'),
(6, 5, 'Korte profil', '', '', '2025-11-10 12:25:30'),
(15, 9, 'alma', '', 'alma teszt', '2025-11-12 18:03:27'),
(16, 9, 'Hopa', '', 'Nanna', '2025-11-12 20:30:12'),
(17, 1, 'TesztRepa', '', '', '2025-11-12 20:51:05'),
(20, 1, 'dani.killermc', '', 'saad', '2025-11-13 14:52:14'),
(23, 1, 'korte', '', '', '2025-11-13 16:17:34');

-- --------------------------------------------------------

--
-- Table structure for table `reminders`
--

CREATE TABLE `reminders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `plant_id` int(10) UNSIGNED NOT NULL,
  `type` enum('water','fertilize','repot','prune','check','custom') NOT NULL,
  `note` text DEFAULT NULL,
  `remind_at` date NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reminders`
--

INSERT INTO `reminders` (`id`, `user_id`, `plant_id`, `type`, `note`, `remind_at`, `created_at`) VALUES
(20, 1, 17, 'water', NULL, '2025-11-11', '2025-11-13 14:09:44'),
(24, 1, 20, 'water', NULL, '2025-11-15', '2025-11-13 14:59:08'),
(26, 1, 20, 'prune', NULL, '2025-11-11', '2025-11-13 14:59:45'),
(27, 1, 17, 'check', NULL, '2025-11-01', '2025-11-13 15:00:08'),
(28, 1, 23, 'water', NULL, '2025-12-20', '2025-11-13 16:17:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `role` enum('user','admin') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password_hash`, `name`, `created_at`, `role`) VALUES
(1, 'dani.killermc@gmail.com', '$2b$12$aJBubxWITUjwfxrUBSGOEOgrzcy0VRFK.QoAVTa4nqN3sP4U6VmXu', 'TesztUser2', '2025-11-08 21:15:57', 'user'),
(2, 'pocketgardener.csapat@gmail.com', '$2b$12$6pshla4SIXIJL9F6IpUzw.fxzRP05b7rjkOugvzHk/GoDslume9um', 'PocketGardener', '2025-11-08 21:38:30', 'user'),
(3, 'gugibors@gmail.com', '$2b$12$LsEwLr6.5mCsjNRK0baX8uSvXaAOEpcUbFaGPs.ZikRnhnMS6lAn.', 'Gugi Bors', '2025-11-10 12:21:45', 'user'),
(4, 'alma@gmail.com', '$2b$12$6zS9X79HPnohvkP9uIjJTusKR8vl.5JxW3NM0fMouSykD.4ASPZDq', 'alma', '2025-11-10 12:22:40', 'user'),
(5, 'kamu@gmail.com', '$2b$12$obgGPixG03ZUd0AxcJjMHORc5yHm7s60mMEYZt1fEZF47HdCZG3cm', 'Fasz', '2025-11-10 12:25:17', 'user'),
(6, 'teszt1@gmail.com', '$2b$12$k9jzITxql5XbakYlXAhLM.4uhsmqFGQyyj2EhP5T1s8dM8f/8m34O', 'tesztelo1', '2025-11-10 13:54:09', 'user'),
(7, 'teszt2@gmail.com', '$2b$12$IUbPF0Ylz3ZiRPWNeedkx.6pB5uiZChcEm13uomz7eZ688XAucz6.', 'tesztelo2', '2025-11-10 13:54:33', 'user'),
(8, 'aaa@gmail.com', '$2b$12$bRy4.KYL4VomZRgRdgEgzOxmGz7nMYDdFuHBoaV3XujgItzYP.9fy', 'aaa', '2025-11-10 14:05:25', 'user'),
(9, 'korte@gmail.com', '$2b$12$U1cNH8NGTH7Lc98IcUPlPOO7nvW4hlI1BIDWGwQr6Db7uej0nRuTK', 'korte', '2025-11-12 16:45:56', 'user'),
(10, 'castello@gmail.com', '$2b$12$LMLh5C9F7m.t/.J.UupngO8qjWAF8pX8Lcdiq3u9FfjJXn4LCrI4K', 'Castello', '2025-11-13 13:22:58', 'user'),
(11, 'admin@admin.com', '$2b$12$M9FS1EMdFyaNOGlsAXw8TONKKac8dvrWKWfiPniKn8hhSuljDu7IK', 'admin', '2025-11-13 15:17:42', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `community_listings`
--
ALTER TABLE `community_listings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `plants`
--
ALTER TABLE `plants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `reminders`
--
ALTER TABLE `reminders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_reminders_plants` (`plant_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `community_listings`
--
ALTER TABLE `community_listings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plants`
--
ALTER TABLE `plants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `reminders`
--
ALTER TABLE `reminders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `community_listings`
--
ALTER TABLE `community_listings`
  ADD CONSTRAINT `community_listings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `plans`
--
ALTER TABLE `plans`
  ADD CONSTRAINT `plans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `plants`
--
ALTER TABLE `plants`
  ADD CONSTRAINT `plants_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reminders`
--
ALTER TABLE `reminders`
  ADD CONSTRAINT `fk_reminders_plants` FOREIGN KEY (`plant_id`) REFERENCES `plants` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reminders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reminders_ibfk_2` FOREIGN KEY (`plant_id`) REFERENCES `plants` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
